#include <string>
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void push_front(int data);
void push_back(int data);
void pop_front();
void pop_back();
int front();
int back();
void append(int data);
void insert(size_t index, const int &item);
bool remove(size_t index);
size_t find(int item);
void display();

#endif