#include "functions.h"
#include <climits>
#include <iostream>
#include <stack>
using namespace std;
class Node {
public:
  int data;
  Node *next;
  Node() {
    data = 0;
    next = NULL;
  }
  Node(int data) {
    this->data = data;
    this->next = NULL;
  }
};
class Linkedlist {
  Node *head;

public:
  Linkedlist() { head = NULL; }
  void push_front(int data) {
    Node *new_node = new Node(data);
    new_node->next = head;
    head = new_node;
  }
  void push_back(int data) {
    Node *new_node = new Node(data);
    if (head == NULL) {
      head = new_node;
    } else {
      Node *current = head;
      while (current->next != NULL) {
        current = current->next;
      }
      current->next = new_node;
    }
  }
  void pop_front() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
    } else {
      Node *temp = head;
      head = head->next;
      delete temp;
    }
  }
  void pop_back() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
    } else if (head->next == NULL) {
      delete head;
      head = NULL;
    } else {
      Node *current = head;
      while (current->next->next != NULL) {
        current = current->next;
      }
      delete current->next;
      current->next = NULL;
    }
  }
  int front() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
      return INT_MIN;
    } else {
      return head->data;
    }
  }
  int back() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
      return INT_MIN;
    } else {
      Node *current = head;
      while (current->next != NULL) {
        current = current->next;
      }
      return current->data;
    }
  }
  void append(int data) {
    Node *new_node = new Node(data);
    if (head == NULL) {
      head = new_node;
    } else {
      Node *current = head;
      while (current->next != NULL) {
        current = current->next;
      }
      current->next = new_node;
    }
  }
  void insert(size_t index, const int &item) {
    if (index == 0) {
      push_front(item);
    } else {
      Node *new_node = new Node(item);
      Node *current = head;
      size_t current_index = 0;
      while (current != NULL && current_index < index - 1) {
        current = current->next;
        current_index++;
      }
      if (current == NULL || current->next == NULL) {
        cout << "Invalid index to insert" << endl;
      } else {
        new_node->next = current->next;
        current->next = new_node;
      }
    }
  }
  bool remove(size_t index) {
    if (head == nullptr || index < 0) {
      cout << "Invalid index to remove" << endl;
      return false;
    }

    if (index == 0) {
      Node *temp = head;
      head = head->next;
      delete temp;
      return true;
    }
    Node *current = head;
    Node *prev = nullptr;
    size_t current_index = 0;
    while (current != nullptr && current_index < index) {
      prev = current;
      current = current->next;
      current_index++;
    }
    if (current == nullptr) {
      cout << "Invalid index to remove" << endl;
      return false;
    }
    prev->next = current->next;
    delete current;
    return true;
  }
  size_t find(int item) {
    Node *current = head;
    size_t index = 0;
    while (current != nullptr) {
      if (current->data == item) {
        return index;
      }
      current = current->next;
      index++;
    }
    // Item not found
    return -1;
  }

  void display() {
    Node *current = head;
    while (current != NULL) {
      cout << current->data << " ";
      current = current->next;
    }
    cout << endl;
  }
};
int main() {
  Linkedlist linkedList;
  linkedList.push_front(10);
  linkedList.push_back(40);
  linkedList.push_back(20);
  linkedList.push_back(30);
  linkedList.
  linkedList.display();
  linkedList.pop_front();
  linkedList.find(0);
  linkedList.remove(0);
}