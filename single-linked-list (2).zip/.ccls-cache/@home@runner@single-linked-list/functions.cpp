#include "functions.h"
#include <climits>
#include <iostream>
#include <stack>