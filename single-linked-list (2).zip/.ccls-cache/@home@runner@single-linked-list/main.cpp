#include "functions.h"
#include <climits>
#include <iostream>
#include <stack>
using namespace std;
//create node class
class Node {
public:
//value held
  int data;
//pointer
  Node *next;
  Node() {
    data = 0;
    next = NULL;
  }
  Node(int data) {
    this->data = data;
    this->next = NULL;
  }
};
//create linked list class
class Linkedlist {
  Node *head;
//create constructor
public:
  Linkedlist() { head = NULL; }
//create push front function
  void push_front(int data) {
    Node *new_node = new Node(data);
    new_node->next = head;
    head = new_node;
  }
//create push back function
  void push_back(int data) {
    Node *new_node = new Node(data);
    //if head is null
    if (head == NULL) {
      //set head to new node
      head = new_node;
    }
    else {
      //create current node
      Node *current = head;
      while (current->next != NULL) {
        current = current->next;
      }
      //set current next to new node
      current->next = new_node;
    }
  }
//create pop front function
  void pop_front() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
    } else {
      //create temp node
      Node *temp = head;
      head = head->next;
      delete temp;
    }
  }
//create pop back function
  void pop_back() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
    }
      //if head next is null
    else if (head->next == NULL) {
      //delete head
      delete head;
      //set head to null
      head = NULL;
    } else {
      //create current node
      Node *current = head;
      while (current->next->next != NULL) {
        //set current to current next
        current = current->next;
      }
      delete current->next;
      current->next = NULL;
    }
  }
//create front function
  int front() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
      //return int min if head is null
      return INT_MIN;
    } else {
      //return head data
      return head->data;
    }
  }
//create back function
  int back() {
    if (head == NULL) {
      cout << "Linkedlist is empty" << endl;
      return INT_MIN;
    } else {
      Node *current = head;
      //while current next is not null
      while (current->next != NULL) {
        current = current->next;
      }
      //return current data
      return current->data;
    }
  }
//create append function
  void append(int data) {
    Node *new_node = new Node(data);
    if (head == NULL) {
      head = new_node;
    } else {
      Node *current = head;
      while (current->next != NULL) {
        current = current->next;
      }
      current->next = new_node;
    }
  }
//create insert function
  void insert(size_t index, const int &item) {
    if (index == 0) {
      push_front(item);
    } else {
      //create new node with item
      Node *new_node = new Node(item);
      Node *current = head;
      size_t current_index = 0;
      //while current is not null and current index is less than index
      while (current != NULL && current_index < index - 1) {
        current = current->next;
        current_index++;
      }
      //if current is null or current next is null
      if (current == NULL || current->next == NULL) {
        cout << "Invalid index to insert" << endl;
      } else {
        //set new node next to current next
        new_node->next = current->next;
        //set current next to new node
        current->next = new_node;
      }
    }
  }
//create remove function
  bool remove(size_t index) {
    //if head is null or index is less than 0
    if (head == nullptr || index < 0) {
      cout << "Invalid index to remove" << endl;
      return false;
    }
//if index is 0
    if (index == 0) {
      //set head to head next
      Node *temp = head;
      head = head->next;
      delete temp;
      return true;
    }
    //create current node
    Node *current = head;
    //create prev node
    Node *prev = nullptr;
    size_t current_index = 0;
    while (current != nullptr && current_index < index) {
      prev = current;
      current = current->next;
      current_index++;
    }
    //if current is null
    if (current == nullptr) {
      cout << "Invalid index to remove" << endl;
      return false;
    }
    prev->next = current->next;
    delete current;
    return true;
  }
//create find function
  size_t find(int item) {
    Node *current = head;
    size_t index = 0;
    while (current != nullptr) {
      //if current data is equal to item
      if (current->data == item) {
        return index;
      }
      current = current->next;
      index++;
    }
    // Item not found
    return -1;
  }

  void display() {
    Node *current = head;
    while (current != NULL) {
      cout << current->data << " ";
      current = current->next;
    }
    cout << endl;
  }
};
int main() {
  Linkedlist linkedList;
  linkedList.push_front(10);
  linkedList.push_back(40);
  linkedList.push_back(20);
  linkedList.push_back(30);
  linkedList.push_back(40);
  linkedList.display();
  linkedList.pop_front();
  linkedList.find(0);
  linkedList.remove(0);
  linkedList.display();
}